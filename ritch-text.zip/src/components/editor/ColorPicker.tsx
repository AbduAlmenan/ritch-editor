'use client';

import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';

const PRESET_COLORS = [
  '#000000', '#434343', '#666666', '#999999', '#b7b7b7', '#cccccc', '#d9d9d9', '#efefef', '#f3f3f3', '#ffffff',
  '#980000', '#ff0000', '#ff9900', '#ffff00', '#00ff00', '#00ffff', '#4a86e8', '#0000ff', '#9900ff', '#ff00ff',
  '#e6b8af', '#f4cccc', '#fce5cd', '#fff2cc', '#d9ead3', '#d0e0e3', '#c9daf8', '#cfe2f3', '#d9d2e9', '#ead1dc',
  '#dd7e6b', '#ea9999', '#f9cb9c', '#ffe599', '#b6d7a8', '#a2c4c9', '#a4c2f4', '#9fc5e8', '#b4a7d6', '#d5a6bd',
  '#cc4125', '#e06666', '#f6b26b', '#ffd966', '#93c47d', '#76a5af', '#6d9eeb', '#6fa8dc', '#8e7cc3', '#c27ba0',
  '#a61c00', '#cc0000', '#e69138', '#f1c232', '#6aa84f', '#45818e', '#3c78d8', '#3d85c6', '#674ea7', '#a64d79',
  '#85200c', '#990000', '#b45f06', '#bf9000', '#38761d', '#134f5c', '#1155cc', '#0b5394', '#351c75', '#741b47',
];

interface ColorPickerProps {
  color: string;
  onChange: (color: string) => void;
  label?: string;
  children: React.ReactNode;
}

export function ColorPicker({ color, onChange, label, children }: ColorPickerProps) {
  const [customColor, setCustomColor] = useState(color);
  const [open, setOpen] = useState(false);

  const handleCustomColorChange = (value: string) => {
    setCustomColor(value);
    if (/^#[0-9a-fA-F]{6}$/.test(value)) {
      onChange(value);
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        {children}
      </PopoverTrigger>
      <PopoverContent className="w-auto p-3" align="start">
        {label && (
          <Label className="text-xs text-muted-foreground mb-2 block">{label}</Label>
        )}
        <div className="grid grid-cols-10 gap-1 mb-3">
          {PRESET_COLORS.map((c) => (
            <button
              key={c}
              className="w-5 h-5 rounded-sm border border-gray-300 hover:scale-110 transition-transform cursor-pointer"
              style={{ backgroundColor: c }}
              onClick={() => {
                onChange(c);
                setCustomColor(c);
              }}
              title={c}
            />
          ))}
        </div>
        <div className="flex items-center gap-2">
          <div
            className="w-6 h-6 rounded-md border border-gray-300 shrink-0"
            style={{ backgroundColor: color }}
          />
          <Input
            value={customColor}
            onChange={(e) => handleCustomColorChange(e.target.value)}
            placeholder="#000000"
            className="h-8 text-xs font-mono"
            maxLength={7}
          />
          <Button
            size="sm"
            variant="outline"
            className="h-8 px-2 text-xs"
            onClick={() => {
              onChange(customColor);
              setOpen(false);
            }}
          >
            Set
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

export default ColorPicker;
